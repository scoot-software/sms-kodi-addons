# sms-kodi-lib
Scoot Media Streamer library for Kodi.
