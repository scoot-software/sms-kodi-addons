# sms-kodi
The official Scoot Media Streamer video addon for Kodi.
