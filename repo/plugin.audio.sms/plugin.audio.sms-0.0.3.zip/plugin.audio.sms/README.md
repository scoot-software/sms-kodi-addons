# sms-kodi
The official Scoot Media Streamer audio addon for Kodi.
