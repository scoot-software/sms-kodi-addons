# Scoot Media Streamer Kodi Repository
The official Scoot Media Streamer repository for Kodi.
